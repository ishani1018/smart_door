import sys
from PyQt6 import QtWidgets
from screens.login import LoginScreen
import sqlite3

def setup_database():
    conn = sqlite3.connect('face_recognition.db')
    cursor = conn.cursor()
    
    # Create entry_logs table if it doesn't exist
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS entry_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id TEXT NOT NULL,
            timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            status TEXT
        )
    ''')
    
    # Create admin table if it doesn't exist
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS admin_users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL
        )
    ''')
    
    # Insert default admin if not exists
    cursor.execute('''
        INSERT OR IGNORE INTO admin_users (username, password) 
        VALUES (?, ?)
    ''', ('admin', 'admin123'))  # Change default credentials as needed
    
    conn.commit()
    conn.close()

def main():
    setup_database()
    app = QtWidgets.QApplication(sys.argv)
    main_window = QtWidgets.QMainWindow()
    ui = LoginScreen()
    ui.mainWindow = main_window
    ui.setupUi(main_window)
    main_window.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()