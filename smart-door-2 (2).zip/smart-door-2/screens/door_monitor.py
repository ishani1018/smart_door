from PyQt6 import QtCore, QtGui, QtWidgets
from PyQt6.QtCore import QTimer
from PyQt6.QtGui import QImage, QPixmap
import cv2
from utils.face_utils import FaceRecognitionSystem
from datetime import datetime
import time

class DoorMonitorScreen(object):
    def __init__(self):
        self.face_recognition = FaceRecognitionSystem()
        self.capture = None
        self.timer = None
        self.log_messages = []
        self.door_status = "Closed"  # Track door status
        self.last_authorized_time = 0  # Track last authorized access

    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(800, 800)
        self.centralwidget = QtWidgets.QWidget(parent=MainWindow)
        self.centralwidget.setObjectName("centralwidget")

        # Title
        self.label = QtWidgets.QLabel(parent=self.centralwidget)
        self.label.setGeometry(QtCore.QRect(200, 20, 400, 41))
        font = QtGui.QFont()
        font.setPointSize(16)
        self.label.setFont(font)
        self.label.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
        self.label.setObjectName("label")
        self.label.setText("Door Monitor System")

        # Door Camera View
        self.doorCameraView = QtWidgets.QGraphicsView(parent=self.centralwidget)
        self.doorCameraView.setGeometry(QtCore.QRect(50, 80, 700, 400))
        self.doorCameraView.setMinimumSize(700, 400)
        
        # Access Log
        self.logTextEdit = QtWidgets.QTextEdit(parent=self.centralwidget)
        self.logTextEdit.setGeometry(QtCore.QRect(50, 500, 700, 200))
        self.logTextEdit.setReadOnly(True)
        self.logTextEdit.setObjectName("logTextEdit")

        # Back Button
        self.backButton = QtWidgets.QPushButton(parent=self.centralwidget)
        self.backButton.setGeometry(QtCore.QRect(600, 720, 150, 40))
        self.backButton.setText("Back")
        self.backButton.clicked.connect(self.back)

        # Door Camera Label
        self.doorLabel = QtWidgets.QLabel(parent=self.centralwidget)
        self.doorLabel.setGeometry(QtCore.QRect(350, 50, 100, 20))
        self.doorLabel.setText("Door Camera")

        # Door Status Label
        self.statusLabel = QtWidgets.QLabel(parent=self.centralwidget)
        self.statusLabel.setGeometry(QtCore.QRect(50, 720, 500, 40))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.statusLabel.setFont(font)
        self.statusLabel.setText("Door Status: Closed")
        
        # Manual Door Control
        self.doorButton = QtWidgets.QPushButton(parent=self.centralwidget)
        self.doorButton.setGeometry(QtCore.QRect(450, 720, 120, 40))
        self.doorButton.setText("Open Door")
        self.doorButton.clicked.connect(self.toggle_door)

        MainWindow.setCentralWidget(self.centralwidget)

        # Initialize camera
        self.capture = cv2.VideoCapture(0)  # Use default camera or adjust index as needed

        # Setup timer for frame updates
        self.timer = QTimer()
        self.timer.timeout.connect(self.update_frame)
        self.timer.start(30)  # Update every 30ms

        # Remove scrollbars from graphics view
        self.doorCameraView.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.doorCameraView.setVerticalScrollBarPolicy(QtCore.Qt.ScrollBarPolicy.ScrollBarAlwaysOff)

    def update_frame(self):
        ret, frame = self.capture.read()
        if ret:
            # Perform face recognition
            face_locations, face_names = self.face_recognition.recognize_face(frame)
            
            authorized_access = False
            
            # Draw results and check authorization
            for (top, right, bottom, left), name in zip(face_locations, face_names):
                # Determine color based on authorization
                if name != "Unknown":
                    color = (0, 255, 0)  # Green for authorized
                    authorized_access = True
                else:
                    color = (0, 0, 255)  # Red for unauthorized
                
                # Draw rectangle around face
                cv2.rectangle(frame, (left, top), (right, bottom), color, 2)
                cv2.putText(frame, name, (left, top - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 2)
                
                # Log and handle door control
                self.handle_access(name, authorized_access)

            # Convert frame to QImage and display
            rgb_image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            h, w, ch = rgb_image.shape
            bytes_per_line = ch * w
            qt_image = QImage(rgb_image.data, w, h, bytes_per_line, QImage.Format.Format_RGB888)
            
            scaled_pixmap = QPixmap.fromImage(qt_image).scaled(
                self.doorCameraView.size(), 
                QtCore.Qt.AspectRatioMode.KeepAspectRatio,
                QtCore.Qt.TransformationMode.SmoothTransformation
            )
            
            scene = QtWidgets.QGraphicsScene()
            scene.addPixmap(scaled_pixmap)
            self.doorCameraView.setScene(scene)
            self.doorCameraView.fitInView(
                scene.sceneRect(),
                QtCore.Qt.AspectRatioMode.KeepAspectRatio
            )

    def handle_access(self, name, authorized):
        current_time = time.time()
        
        # Only process if it's been more than 5 seconds since last authorization
        if current_time - self.last_authorized_time > 5:
            if authorized:
                self.open_door()
                self.log_access(name, "Access Granted")
                self.last_authorized_time = current_time
            else:
                self.close_door()
                self.log_access(name, "Access Denied")

    def open_door(self):
        self.door_status = "Open"
        self.statusLabel.setText("Door Status: Open")
        self.doorButton.setText("Close Door")
        # Add your door control hardware code here
        # For example: GPIO.output(DOOR_PIN, GPIO.HIGH)
        
        # Auto-close door after 5 seconds
        QTimer.singleShot(5000, self.close_door)

    def close_door(self):
        self.door_status = "Closed"
        self.statusLabel.setText("Door Status: Closed")
        self.doorButton.setText("Open Door")
        # Add your door control hardware code here
        # For example: GPIO.output(DOOR_PIN, GPIO.LOW)

    def toggle_door(self):
        if self.door_status == "Closed":
            self.open_door()
        else:
            self.close_door()

    def log_access(self, name, status):
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_message = f"[{timestamp}] {name}: {status}"
        
        # Add to log if it's a new message
        if not self.log_messages or self.log_messages[-1] != log_message:
            self.log_messages.append(log_message)
            self.logTextEdit.append(log_message)
            
            # If access denied, make the log entry red
            if "Denied" in status:
                cursor = self.logTextEdit.textCursor()
                format = QtGui.QTextCharFormat()
                format.setForeground(QtGui.QColor("red"))
                cursor.movePosition(QtGui.QTextCursor.MoveOperation.End)
                cursor.movePosition(
                    QtGui.QTextCursor.MoveOperation.StartOfLine,
                    QtGui.QTextCursor.MoveMode.KeepAnchor
                )
                cursor.movePosition(
                    QtGui.QTextCursor.MoveOperation.End,
                    QtGui.QTextCursor.MoveMode.KeepAnchor
                )
                cursor.mergeCharFormat(format)

    def back(self):
        # Clean up resources
        if self.capture:
            self.capture.release()
        if self.timer:
            self.timer.stop()
        # Close door before leaving
        self.close_door()
        
        # Return to home screen
        from screens.home import HomeScreen
        self.home_screen = HomeScreen()
        self.home_screen.mainWindow = self.mainWindow
        self.home_screen.setupUi(self.mainWindow)