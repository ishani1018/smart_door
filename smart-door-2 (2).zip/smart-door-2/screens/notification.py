from PyQt6 import QtCore, QtGui, QtWidgets
import sqlite3
from datetime import datetime

class NotificationScreen(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(800, 600)
        self.centralwidget = QtWidgets.QWidget(parent=MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        
        # Title Label
        self.label = QtWidgets.QLabel(parent=self.centralwidget)
        self.label.setGeometry(QtCore.QRect(280, 40, 221, 41))
        font = QtGui.QFont()
        font.setPointSize(13)
        self.label.setFont(font)
        self.label.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
        self.label.setObjectName("label")
        
        # User ID Label
        self.label_2 = QtWidgets.QLabel(parent=self.centralwidget)
        self.label_2.setGeometry(QtCore.QRect(50, 140, 71, 16))
        self.label_2.setObjectName("label_2")
        
        # User ID Input
        self.lineEdit = QtWidgets.QLineEdit(parent=self.centralwidget)
        self.lineEdit.setGeometry(QtCore.QRect(150, 140, 231, 31))
        self.lineEdit.setObjectName("lineEdit")
        self.lineEdit.textChanged.connect(self.search_timestamps)
        
        # Search Button
        self.searchButton = QtWidgets.QPushButton(parent=self.centralwidget)
        self.searchButton.setGeometry(QtCore.QRect(390, 140, 93, 31))
        self.searchButton.setText("Search")
        self.searchButton.clicked.connect(self.search_timestamps)
        
        # Timestamp Label
        self.label_3 = QtWidgets.QLabel(parent=self.centralwidget)
        self.label_3.setGeometry(QtCore.QRect(50, 190, 91, 31))
        self.label_3.setWordWrap(True)
        self.label_3.setObjectName("label_3")
        
        # Timestamp Output Box
        self.textEdit = QtWidgets.QTextEdit(parent=self.centralwidget)
        self.textEdit.setGeometry(QtCore.QRect(150, 190, 500, 200))
        self.textEdit.setReadOnly(True)
        self.textEdit.setObjectName("textEdit")
        
        # Back Button
        self.pushButton = QtWidgets.QPushButton(parent=self.centralwidget)
        self.pushButton.setGeometry(QtCore.QRect(550, 420, 93, 31))
        self.pushButton.setObjectName("pushButton")
        self.pushButton.clicked.connect(self.back)
        
        MainWindow.setCentralWidget(self.centralwidget)
        self.statusbar = QtWidgets.QStatusBar(parent=MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "Real Time Notification"))
        self.label.setText(_translate("MainWindow", "Real Time Notification System"))
        self.label_2.setText(_translate("MainWindow", "User ID"))
        self.label_3.setText(_translate("MainWindow", "Timestamp of\nthe entry"))
        self.pushButton.setText(_translate("MainWindow", "Back"))

    def back(self):
        from screens.home import HomeScreen
        self.home_screen = HomeScreen()
        self.home_screen.mainWindow = self.mainWindow
        self.home_screen.setupUi(self.mainWindow) 

    def search_timestamps(self):
        user_id = self.lineEdit.text().strip()
        if not user_id:
            self.textEdit.clear()
            return

        try:
            # Connect to SQLite database
            conn = sqlite3.connect('face_recognition.db')
            cursor = conn.cursor()
            
            # Get all timestamps for the user
            cursor.execute("""
                SELECT timestamp, status FROM entry_logs 
                WHERE user_id = ? 
                ORDER BY timestamp DESC
            """, (user_id,))
            
            results = cursor.fetchall()
            
            if results:
                # Format the results
                output_text = ""
                for timestamp, status in results:
                    formatted_time = datetime.fromisoformat(timestamp).strftime('%Y-%m-%d %H:%M:%S')
                    output_text += f"Time: {formatted_time} - Status: {status}\n"
                self.textEdit.setText(output_text)
            else:
                self.textEdit.setText("No entries found for this user ID")
                
        except sqlite3.Error as e:
            self.textEdit.setText(f"Database error: {str(e)}")
        finally:
            if conn:
                conn.close()