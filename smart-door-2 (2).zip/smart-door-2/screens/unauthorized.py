from PyQt6 import QtCore, QtGui, QtWidgets
import cv2
from PyQt6.QtCore import QTimer
from PyQt6.QtGui import QImage, QPixmap
from utils.face_utils import FaceRecognitionSystem

class UnauthorizedScreen(object):
    def __init__(self):
        self.face_recognition = FaceRecognitionSystem()
        self.capture = None
        self.timer = None

    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(800, 600)
        self.centralwidget = QtWidgets.QWidget(parent=MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        
        # Title Label
        self.label = QtWidgets.QLabel(parent=self.centralwidget)
        self.label.setGeometry(QtCore.QRect(280, 40, 221, 41))
        font = QtGui.QFont()
        font.setPointSize(13)
        self.label.setFont(font)
        self.label.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
        self.label.setObjectName("label")
        
        # Image Label
        self.label_2 = QtWidgets.QLabel(parent=self.centralwidget)
        self.label_2.setGeometry(QtCore.QRect(50, 120, 71, 16))
        self.label_2.setObjectName("label_2")
        
        # Image Display Area
        self.graphicsView = QtWidgets.QGraphicsView(parent=self.centralwidget)
        self.graphicsView.setGeometry(QtCore.QRect(280, 100, 231, 191))
        self.graphicsView.setObjectName("graphicsView")
        
        # Buttons
        self.pushButton = QtWidgets.QPushButton(parent=self.centralwidget)
        self.pushButton.setGeometry(QtCore.QRect(180, 320, 93, 31))
        self.pushButton.setObjectName("pushButton")
        
        self.pushButton_2 = QtWidgets.QPushButton(parent=self.centralwidget)
        self.pushButton_2.setGeometry(QtCore.QRect(300, 320, 93, 31))
        self.pushButton_2.setObjectName("pushButton_2")
        
        self.pushButton_3 = QtWidgets.QPushButton(parent=self.centralwidget)
        self.pushButton_3.setGeometry(QtCore.QRect(420, 320, 93, 31))
        self.pushButton_3.setObjectName("pushButton_3")
        self.pushButton_3.clicked.connect(self.back)
        
        MainWindow.setCentralWidget(self.centralwidget)
        self.statusbar = QtWidgets.QStatusBar(parent=MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        # Initialize camera
        self.capture = cv2.VideoCapture(0)
        self.timer = QTimer()
        self.timer.timeout.connect(self.update_frame)
        self.timer.start(30)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "Unauthorized Access Management"))
        self.label.setText(_translate("MainWindow", "Unauthorized Access Management"))
        self.label_2.setText(_translate("MainWindow", "Image"))
        self.pushButton.setText(_translate("MainWindow", "Grant Access"))
        self.pushButton_2.setText(_translate("MainWindow", "Grant Deny"))
        self.pushButton_3.setText(_translate("MainWindow", "Back"))

    def update_frame(self):
        ret, frame = self.capture.read()
        if ret:
            # Perform face recognition
            face_locations, face_names = self.face_recognition.recognize_face(frame)
            
            # Draw results on frame
            for (top, right, bottom, left), name in zip(face_locations, face_names):
                cv2.rectangle(frame, (left, top), (right, bottom), (0, 255, 0), 2)
                cv2.putText(frame, name, (left, top - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)

            # Convert frame to QImage
            rgb_image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            h, w, ch = rgb_image.shape
            bytes_per_line = ch * w
            qt_image = QImage(rgb_image.data, w, h, bytes_per_line, QImage.Format.Format_RGB888)
            
            # Scale the image to fit the graphics view
            scaled_pixmap = QPixmap.fromImage(qt_image).scaled(
                self.graphicsView.size(), 
                QtCore.Qt.AspectRatioMode.KeepAspectRatio,
                QtCore.Qt.TransformationMode.SmoothTransformation
            )
            
            # Clear existing scene and add new pixmap
            scene = QtWidgets.QGraphicsScene()
            scene.addPixmap(scaled_pixmap)
            self.graphicsView.setScene(scene)
            self.graphicsView.fitInView(
                scene.sceneRect(),
                QtCore.Qt.AspectRatioMode.KeepAspectRatio
            )

    def back(self):
        if self.capture:
            self.capture.release()
        if self.timer:
            self.timer.stop()
        from screens.home import HomeScreen
        self.home_screen = HomeScreen()
        self.home_screen.mainWindow = self.mainWindow
        self.home_screen.setupUi(self.mainWindow) 